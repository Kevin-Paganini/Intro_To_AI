class NullBoard:
    def place_piece(self, row, pos, player):
        pass
